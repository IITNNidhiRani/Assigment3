INSTANCE_GROUP="api-039-instance-group"
ZONE="us-central1-c"
MIN_INSTANCES=2
MAX_INSTANCES=5
TARGET_INSTANCES=3
CPU_UTILIZATION=0.7
COOL_DOWN=90

echo "Increasing instances in GCP Managed Instance Group..."
/home/vboxuser/StressTest/google-cloud-sdk/bin/gcloud compute instance-groups managed resize $INSTANCE_GROUP --size=$TARGET_INSTANCES --zone=$ZONE

#/home/vboxuser/StressTest/google-cloud-sdk/bin/gcloud compute instance-groups managed set-autoscaling $INSTANCE_GROUP \
#    --zone=$ZONE \
#    --min-num-replicas=$MIN_INSTANCES \
#    --max-num-replicas=$MAX_INSTANCES \
#    --target-cpu-utilization=$CPU_UTILIZATION \
#    --cool-down-period=$COOL_DOWN
	
echo "Updated scaling limits: min=$MIN_INSTANCES, max=$MAX_INSTANCES"

echo "Current instances in the instance group:"
/home/vboxuser/StressTest/google-cloud-sdk/bin/gcloud compute instance-groups managed list-instances $INSTANCE_GROUP --zone=$ZONE


