import multiprocessing  
import time  

def stress_cpu():  
    while True:  
        pass  # Consume CPU time indefinitely  

def stress_memory():  
    data = []  
    while True:  
        data.append(' ' * 10**6)  # Allocate 1 MB chunks indefinitely  

if __name__ == "__main__":  
    print("Starting stress test on Docker...")  
    processes = []  

    # CPU Stress (number of CPU cores)  
    for _ in range(multiprocessing.cpu_count()):  
        p = multiprocessing.Process(target=stress_cpu)  
        processes.append(p)  
        p.start()  

    # Memory Stress (adjustable, keep it proportional to RAM)  
    memory_process = multiprocessing.Process(target=stress_memory)  
    processes.append(memory_process)  
    memory_process.start()  

    try:  
        while True:  
            time.sleep(1)  # Keep the script running  
    except KeyboardInterrupt:  
        print("Stopping stress test...")  
        for p in processes:  
            p.terminate()
